from urllib.parse import unquote


class ValidateProjectReportLogic:
    """Shared source normalization and project-layer comparison logic."""

    @staticmethod
    def normalize_path(path, case_sensitive):
        if not path:
            return ""

        if path.lower().startswith("file:"):
            normalized = path[5:]
            while normalized.startswith("/"):
                normalized = normalized[1:]
            normalized = unquote(normalized)
            if "?" in normalized:
                normalized = normalized.split("?", 1)[0]
        else:
            normalized = path.strip().replace("\\", "/")

        if "|" in normalized:
            normalized = normalized.split("|", 1)[0]
        if not case_sensitive:
            normalized = normalized.lower()
        while "//" in normalized:
            normalized = normalized.replace("//", "/")
        return normalized

    @classmethod
    def build_possible_layers(
        cls,
        source_rows,
        use_filter1,
        selected_categories1,
        use_filter2,
        selected_categories2,
        use_filter3,
        selected_categories3,
        case_sensitive,
    ):
        possible_layers = {}
        for (
            layer_name,
            source_path,
            category1,
            category2,
            category3,
        ) in source_rows:
            if use_filter1 and (
                not category1 or str(category1) not in selected_categories1
            ):
                continue
            if use_filter2 and (
                not category2 or str(category2) not in selected_categories2
            ):
                continue
            if use_filter3 and (
                not category3 or str(category3) not in selected_categories3
            ):
                continue

            if layer_name and source_path:
                normalized_layer_name = cls.normalize_path(layer_name, case_sensitive)
                normalized_source_path = cls.normalize_path(source_path, case_sensitive)
                possible_layers[normalized_layer_name] = {
                    "original_layer_name": layer_name,
                    "original_source_path": str(source_path),
                    "source_path": normalized_source_path,
                    "category1": category1,
                    "category2": category2,
                    "category3": category3,
                }
        return possible_layers

    @classmethod
    def wrong_source_fixes(
        cls,
        project_layers,
        possible_layers,
        layer_name_delimiter,
        case_sensitive,
    ):
        """Return project layers whose matching index row supplies another source."""
        fixes = []
        for layer in project_layers.values():
            normalized_layer_name = cls.normalize_path(layer.name(), case_sensitive)
            if layer_name_delimiter in normalized_layer_name:
                normalized_layer_name = normalized_layer_name.split(
                    layer_name_delimiter, 1
                )[0]

            reference = possible_layers.get(normalized_layer_name)
            if reference is None:
                continue
            current_source = cls.normalize_path(
                layer.dataProvider().dataSourceUri(), case_sensitive
            )
            if current_source != reference["source_path"]:
                fixes.append((layer, reference["original_source_path"]))
        return fixes

    @classmethod
    def validate_project_layers(
        cls,
        project_layers,
        possible_layers,
        layer_name_delimiter,
        case_sensitive,
        progress_callback=None,
    ):
        html_rows = []
        unmatched_layers = possible_layers.copy()
        matched_count = 0
        wrong_source_count = 0
        layer_name_not_found_count = 0
        total_count = 0

        for layer in project_layers.values():
            layer_name = layer.name()
            layer_source = layer.dataProvider().dataSourceUri()
            normalized_layer_name = cls.normalize_path(layer_name, case_sensitive)
            if layer_name_delimiter in normalized_layer_name:
                normalized_layer_name = normalized_layer_name.split(
                    layer_name_delimiter, 1
                )[0]
                if progress_callback:
                    progress_callback(
                        f"Layer name '{layer_name}' normalized to "
                        f"'{normalized_layer_name}' using delimiter "
                        f"'{layer_name_delimiter}'"
                    )
            normalized_layer_source = cls.normalize_path(layer_source, case_sensitive)

            if normalized_layer_name in possible_layers:
                reference = possible_layers[normalized_layer_name]
                reference_source = reference[
                    "original_source_path"
                ]
                category1 = possible_layers[normalized_layer_name]["category1"]
                category2 = possible_layers[normalized_layer_name]["category2"]
                category3 = possible_layers[normalized_layer_name]["category3"]
                if normalized_layer_source == reference["source_path"]:
                    check_result = "MATCHED"
                    matched_count += 1
                else:
                    check_result = "WRONGSOURCE"
                    wrong_source_count += 1
                unmatched_layers.pop(normalized_layer_name, None)
            else:
                reference_source = ""
                category1 = ""
                category2 = ""
                category3 = ""
                check_result = "LAYERNAMENOTFOUND"
                layer_name_not_found_count += 1

            if not layer_name or not check_result or not normalized_layer_source:
                if progress_callback:
                    progress_callback(f"Skipping blank line for layer '{layer_name}'")
                continue

            total_count += 1
            html_rows.append(
                (
                    layer_name,
                    check_result,
                    layer_source,
                    reference_source,
                    category1,
                    category2,
                    category3,
                    layer.id(),
                )
            )
            if progress_callback:
                progress_callback(f"Layer '{layer_name}' checked: {check_result}")

        return (
            html_rows,
            unmatched_layers,
            matched_count,
            wrong_source_count,
            layer_name_not_found_count,
            total_count,
        )
